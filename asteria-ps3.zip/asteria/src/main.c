/*
 * Asteria - tela inicial para PS3 (PSL1GHT nativo, sem SDL)
 *
 * O SDL travava dentro do SDL_RenderPresent apos ~250 frames. Agora o jogo
 * fala direto com o RSX (framebuffer duplo + flip com vsync), compoe a imagem
 * na memoria normal e copia para a tela somente as areas que mudaram.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <malloc.h>
#include <sys/time.h>

#include <ppu-types.h>
#include <rsx/rsx.h>
#include <sysutil/sysutil.h>
#include <io/pad.h>

#if defined(__has_include)
#if __has_include(<sysutil/video_out.h>)
#define HAVE_VIDEO_OUT 1
#endif
#endif

#ifdef HAVE_VIDEO_OUT
#include <sysutil/video_out.h>
typedef videoOutState         vstate_t;
typedef videoOutResolution    vres_t;
typedef videoOutConfiguration vconf_t;
#define v_get_state       videoOutGetState
#define v_get_resolution  videoOutGetResolution
#define v_configure       videoOutConfigure
#define V_FMT_XRGB        VIDEO_OUT_BUFFER_FORMAT_XRGB
#else
#include <sysutil/video.h>
typedef videoState         vstate_t;
typedef videoResolution    vres_t;
typedef videoConfiguration vconf_t;
#define v_get_state       videoGetState
#define v_get_resolution  videoGetResolution
#define v_configure       videoConfigure
#define V_FMT_XRGB        VIDEO_BUFFER_FORMAT_XRGB
#endif

#pragma weak gettimeofday

#define LW 1280               /* resolucao logica do jogo */
#define LH 720
#define CB_SIZE   0x100000
#define HOST_SIZE (32 * 1024 * 1024)
#define TARGET_FPS 60

/* ---------- assets embutidos no ELF (.incbin) ---------- */
#define INCBIN(sym, file)                                   \
    __asm__(".section .rodata\n"                            \
            ".balign 16\n"                                  \
            ".global " #sym "\n"                            \
            #sym ":\n"                                      \
            ".incbin \"" file "\"\n"                        \
            ".balign 16\n"                                  \
            ".previous\n");                                 \
    extern const unsigned char sym[]

INCBIN(bg_data,            "assets/bg.raw");
INCBIN(btn_jogar_n_data,   "assets/btn_jogar_n.raw");
INCBIN(btn_jogar_s_data,   "assets/btn_jogar_s.raw");
INCBIN(btn_config_n_data,  "assets/btn_config_n.raw");
INCBIN(btn_config_s_data,  "assets/btn_config_s.raw");
INCBIN(btn_creditos_n_data,"assets/btn_creditos_n.raw");
INCBIN(btn_creditos_s_data,"assets/btn_creditos_s.raw");

#define BTN_W 258
#define BTN_H 55

/* ---------- utilidades ---------- */
static float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static float ease_out_cubic(float t) { t = clampf(t, 0.f, 1.f); float u = 1.f - t; return 1.f - u * u * u; }
static float lerpf(float a, float b, float t) { return a + (b - a) * t; }

static u32 rng_state = 0x1234ABCDu;
static u32 rnd(void) { rng_state ^= rng_state << 13; rng_state ^= rng_state >> 17; rng_state ^= rng_state << 5; return rng_state; }
static float rndf(void) { return (rnd() & 0xFFFFFF) / 16777216.0f; }

static double now_sec(void)
{
    static double fake = 0.0;
    if (gettimeofday) {
        struct timeval tv;
        gettimeofday(&tv, NULL);
        return (double)tv.tv_sec + (double)tv.tv_usec * 1e-6;
    }
    fake += 1.0 / 60.0;   /* sem relogio: assume vsync de 60 Hz */
    return fake;
}

/* ====================================================================== */
/*  Tela (RSX) e composicao em memoria                                     */
/* ====================================================================== */
static gcmContextData *context = NULL;
static u32 dw, dh;                 /* resolucao real da saida */
static u32 fb_pitch;               /* bytes por linha */
static u32 *fb[2];                 /* framebuffers na memoria do RSX */
static u32 fb_off[2];

static u32 *host = NULL;           /* quadro composto (LW x LH) */
static u32 *bgp  = NULL;           /* background pronto (LW x LH) */
static int *xmap = NULL, *ymap = NULL;

static volatile int stage = 0;
static unsigned flip_timeouts = 0;
static int running = 1;

/* ---- lista de areas sujas ---- */
typedef struct { short x0, y0, x1, y1; } Rect;
#define MAXR 1024
typedef struct { Rect r[MAXR]; int n; int full; } RList;
static RList lists[3];
static RList *cur = &lists[0];

static int clip(int *x, int *y, int *w, int *h)
{
    int x0 = *x, y0 = *y, x1 = *x + *w, y1 = *y + *h;
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > LW) x1 = LW;
    if (y1 > LH) y1 = LH;
    if (x1 <= x0 || y1 <= y0) return 0;
    *x = x0; *y = y0; *w = x1 - x0; *h = y1 - y0;
    return 1;
}

static void touch(int x, int y, int w, int h)
{
    if (!clip(&x, &y, &w, &h)) return;
    if (cur->n >= MAXR) { cur->full = 1; return; }
    Rect *r = &cur->r[cur->n++];
    r->x0 = (short)x; r->y0 = (short)y; r->x1 = (short)(x + w); r->y1 = (short)(y + h);
}

static void restore_list(const RList *l)
{
    if (l->full) { memcpy(host, bgp, (size_t)LW * LH * 4); return; }
    for (int i = 0; i < l->n; i++) {
        const Rect *r = &l->r[i];
        for (int y = r->y0; y < r->y1; y++)
            memcpy(host + y * LW + r->x0, bgp + y * LW + r->x0, (size_t)(r->x1 - r->x0) * 4);
    }
}

/* copia uma area do quadro composto para o framebuffer (com escala se preciso) */
static void copy_rect(u32 *dst, int x0, int y0, int x1, int y1)
{
    if (dw == LW && dh == LH) {
        for (int y = y0; y < y1; y++)
            memcpy(dst + (size_t)y * dw + x0, host + y * LW + x0, (size_t)(x1 - x0) * 4);
        return;
    }
    int X0 = (int)((long)x0 * dw / LW), X1 = (int)(((long)x1 * dw + LW - 1) / LW);
    int Y0 = (int)((long)y0 * dh / LH), Y1 = (int)(((long)y1 * dh + LH - 1) / LH);
    if (X1 > (int)dw) X1 = (int)dw;
    if (Y1 > (int)dh) Y1 = (int)dh;
    for (int y = Y0; y < Y1; y++) {
        const u32 *src = host + ymap[y] * LW;
        u32 *d = dst + (size_t)y * dw;
        for (int x = X0; x < X1; x++) d[x] = src[xmap[x]];
    }
}

static void copy_list(u32 *dst, const RList *l)
{
    if (l->full) { copy_rect(dst, 0, 0, LW, LH); return; }
    for (int i = 0; i < l->n; i++)
        copy_rect(dst, l->r[i].x0, l->r[i].y0, l->r[i].x1, l->r[i].y1);
}

/* ---- primitivas de desenho (no quadro em memoria) ---- */
static void blend_nt(int x, int y, int w, int h, int cr, int cg, int cb, int a)
{
    if (a <= 0 || !clip(&x, &y, &w, &h)) return;
    if (a > 255) a = 255;
    unsigned ia = 255 - a, sr = cr * a, sg = cg * a, sb = cb * a;
    for (int yy = 0; yy < h; yy++) {
        u32 *p = host + (y + yy) * LW + x;
        for (int xx = 0; xx < w; xx++) {
            u32 d = p[xx];
            unsigned r = (sr + ((d >> 16) & 255) * ia + 127) / 255;
            unsigned g = (sg + ((d >> 8) & 255) * ia + 127) / 255;
            unsigned b = (sb + (d & 255) * ia + 127) / 255;
            p[xx] = (r << 16) | (g << 8) | b;
        }
    }
}
static void blend(int x, int y, int w, int h, int cr, int cg, int cb, int a)
{
    touch(x, y, w, h);
    blend_nt(x, y, w, h, cr, cg, cb, a);
}

static void solid_nt(int x, int y, int w, int h, u32 col)
{
    if (!clip(&x, &y, &w, &h)) return;
    for (int yy = 0; yy < h; yy++) {
        u32 *p = host + (y + yy) * LW + x;
        for (int xx = 0; xx < w; xx++) p[xx] = col;
    }
}

/* sprite RGBA (bytes) com alpha global 0..255; nao registra area suja */
static void blit_sprite_nt(const unsigned char *s, int sw, int sh, int dx, int dy, int ga)
{
    if (ga <= 0) return;
    int x = dx, y = dy, w = sw, h = sh;
    if (!clip(&x, &y, &w, &h)) return;
    for (int yy = y; yy < y + h; yy++) {
        const unsigned char *q = s + ((yy - dy) * sw + (x - dx)) * 4;
        u32 *p = host + yy * LW + x;
        for (int xx = 0; xx < w; xx++, q += 4) {
            unsigned a = (q[3] * (unsigned)ga + 127) / 255;
            if (!a) continue;
            u32 d = p[xx];
            unsigned ia = 255 - a;
            unsigned r = (q[0] * a + ((d >> 16) & 255) * ia + 127) / 255;
            unsigned g = (q[1] * a + ((d >> 8) & 255) * ia + 127) / 255;
            unsigned b = (q[2] * a + (d & 255) * ia + 127) / 255;
            p[xx] = (r << 16) | (g << 8) | b;
        }
    }
}

/* ---------- fonte bitmap 5x7 (contador de FPS) ---------- */
static const u8 *glyph(char c)
{
    static const u8 G_F[7] = {31,16,16,30,16,16,16};
    static const u8 G_P[7] = {30,17,17,30,16,16,16};
    static const u8 G_S[7] = {15,16,16,14,1,1,30};
    static const u8 G_C[7] = {0,4,4,0,4,4,0};
    static const u8 G_D[10][7] = {
        {14,17,19,21,25,17,14}, {4,12,4,4,4,4,14}, {14,17,1,2,4,8,31},
        {30,1,1,14,1,1,30},     {2,6,10,18,31,2,2}, {31,16,30,1,1,17,14},
        {6,8,16,30,17,17,14},   {31,1,2,4,8,8,8},   {14,17,17,14,17,17,14},
        {14,17,17,15,1,2,12}
    };
    if (c == 'F') return G_F;
    if (c == 'P') return G_P;
    if (c == 'S') return G_S;
    if (c == ':') return G_C;
    if (c >= '0' && c <= '9') return G_D[c - '0'];
    return NULL;
}

static void draw_text_nt(const char *s, int x, int y, int px, u32 col)
{
    for (; *s; s++) {
        const u8 *g = glyph(*s);
        if (g)
            for (int row = 0; row < 7; row++)
                for (int c = 0; c < 5; c++)
                    if (g[row] & (1 << (4 - c)))
                        solid_nt(x + c * px, y + row * px, px, px, col);
        x += 6 * px;
    }
}
static int text_width(const char *s, int px) { return (int)strlen(s) * 6 * px - px; }

/* ---------- estrelas cintilantes ---------- */
#define NSTARS 90
typedef struct { float x, y, ph, sp; int sz; u8 r, g, b; } Star;
static Star stars[NSTARS];

static void init_stars(void)
{
    for (int i = 0; i < NSTARS; i++) {
        stars[i].x  = rndf() * LW;
        stars[i].y  = rndf() * (LH * 0.78f);
        stars[i].ph = rndf() * 6.2831f;
        stars[i].sp = 0.8f + rndf() * 2.4f;
        stars[i].sz = (rnd() % 7 == 0) ? 3 : ((rnd() % 3 == 0) ? 2 : 1);
        int k = rnd() % 4;
        if (k == 0)      { stars[i].r = 255; stars[i].g = 200; stars[i].b = 240; }
        else if (k == 1) { stars[i].r = 190; stars[i].g = 215; stars[i].b = 255; }
        else             { stars[i].r = 255; stars[i].g = 255; stars[i].b = 255; }
    }
}

static void draw_stars(float t)
{
    for (int i = 0; i < NSTARS; i++) {
        float tw = 0.5f + 0.5f * sinf(t * stars[i].sp + stars[i].ph);
        int a = (int)(tw * tw * 200.f);
        int s = stars[i].sz, cx = (int)stars[i].x, cy = (int)stars[i].y;
        if (s >= 3) {
            touch(cx - 3, cy - 3, 9, 9);
            blend_nt(cx, cy, s, s, stars[i].r, stars[i].g, stars[i].b, a);
            blend_nt(cx - 3, cy + 1, 9, 1, stars[i].r, stars[i].g, stars[i].b, a / 2);
            blend_nt(cx + 1, cy - 3, 1, 9, stars[i].r, stars[i].g, stars[i].b, a / 2);
        } else {
            blend(cx, cy, s, s, stars[i].r, stars[i].g, stars[i].b, a);
        }
    }
}

/* ---------- estrela cadente ---------- */
typedef struct { int active; float t, dur, x0, y0, dx, dy, next; } Meteor;

static void update_meteor(Meteor *m, float dt)
{
    if (!m->active) {
        m->next -= dt;
        if (m->next <= 0.f) {
            m->active = 1; m->t = 0.f; m->dur = 0.8f + rndf() * 0.4f;
            m->x0 = 500.f + rndf() * 700.f; m->y0 = 20.f + rndf() * 160.f;
            m->dx = -(260.f + rndf() * 140.f); m->dy = 120.f + rndf() * 70.f;
        }
    } else {
        m->t += dt;
        if (m->t >= m->dur) { m->active = 0; m->next = 3.5f + rndf() * 4.5f; }
    }
}

static void draw_meteor(const Meteor *m)
{
    if (!m->active) return;
    float p = m->t / m->dur;
    float fade = sinf(p * 3.14159f);
    float hx = m->x0 + m->dx * p * 1.6f, hy = m->y0 + m->dy * p * 1.6f;
    for (int i = 0; i < 16; i++) {
        float k = i / 16.0f;
        int x = (int)(hx - m->dx * 0.16f * k), y = (int)(hy - m->dy * 0.16f * k);
        int sz = i < 3 ? 3 : 2;
        blend(x, y, sz, sz, 255, 225, 250, (int)(fade * (1.f - k) * 230.f));
    }
}

/* ---------- botoes ---------- */
#define NBTN 3
typedef struct {
    const unsigned char *n, *s;
    float cx, cy;
    float sel;     /* 0..1 transicao normal -> selecionado */
    float press;   /* animacao de clique */
} Button;

static void draw_diamond(int cx, int cy, int px, int a)
{
    static const int w[5] = {1, 3, 5, 3, 1};
    for (int row = 0; row < 5; row++)
        blend_nt(cx - (w[row] * px) / 2, cy + (row - 2) * px, w[row] * px, px, 255, 170, 230, a);
}

static void draw_button(Button *b, int index, float t, float intro)
{
    float e = ease_out_cubic((intro - 0.35f - index * 0.14f) / 0.55f);
    if (e <= 0.f) return;

    float slide = (1.f - e) * 30.f;
    float lift  = -4.f * b->sel + 4.f * sinf(b->press * 3.14159f);
    int dx = (int)(b->cx - BTN_W / 2), dy = (int)(b->cy - BTN_H / 2 + slide + lift);
    int alpha = (int)(e * 255.f);

    if (b->sel > 0.02f) touch(dx - 44, dy - 16, BTN_W + 88, BTN_H + 32);
    else                touch(dx, dy, BTN_W, BTN_H);

    if (b->sel > 0.02f) {
        float pulse = 0.65f + 0.35f * sinf(t * 4.2f);
        for (int i = 3; i >= 1; i--) {
            int g = i * 4;
            blend_nt(dx - g, dy - g, BTN_W + g * 2, BTN_H + g * 2, 255, 140, 220,
                     (int)(b->sel * pulse * e * (28.f - i * 6.f)));
        }
        float bob = sinf(t * 5.f) * 4.f;
        int da = (int)(b->sel * e * 235.f);
        draw_diamond(dx - 26 - (int)bob, dy + BTN_H / 2, 3, da);
        draw_diamond(dx + BTN_W + 26 + (int)bob, dy + BTN_H / 2, 3, da);
    }

    blit_sprite_nt(b->n, BTN_W, BTN_H, dx, dy, alpha);
    if (b->sel > 0.01f) blit_sprite_nt(b->s, BTN_W, BTN_H, dx, dy, (int)(b->sel * alpha));
    if (b->press > 0.01f && b->press < 0.6f)
        blend_nt(dx, dy, BTN_W, BTN_H, 255, 210, 245, (int)((0.6f - b->press) * 150.f));
}

/* ====================================================================== */
/*  Inicializacao do RSX / video                                           */
/* ====================================================================== */
static void wait_flip(void)
{
    int n = 0;
    while (gcmGetFlipStatus() != 0) {
        usleep(200);
        if (++n > 1500) { flip_timeouts++; break; }   /* nunca fica preso para sempre */
    }
    gcmResetFlipStatus();
}

static void queue_flip(u32 id)
{
    gcmSetFlip(context, id);
    rsxFlushBuffer(context);
    gcmSetWaitFlip(context);
}

static int init_screen(void)
{
    void *host_addr = memalign(1024 * 1024, HOST_SIZE);
    if (!host_addr) return 0;
    rsxInit(&context, CB_SIZE, HOST_SIZE, host_addr);

    vstate_t state;
    vres_t res;
    vconf_t vconfig;
    v_get_state(0, 0, &state);
    v_get_resolution(state.displayMode.resolution, &res);
    memset(&vconfig, 0, sizeof(vconfig));
    vconfig.resolution = state.displayMode.resolution;
    vconfig.format = V_FMT_XRGB;
    vconfig.pitch = res.width * sizeof(u32);
    v_configure(0, &vconfig, NULL, 0);
    v_get_state(0, 0, &state);

    gcmSetFlipMode(GCM_FLIP_VSYNC);

    dw = res.width;
    dh = res.height;
    fb_pitch = dw * sizeof(u32);
    for (int i = 0; i < 2; i++) {
        fb[i] = (u32 *)rsxMemalign(64, dh * fb_pitch);
        if (!fb[i]) return 0;
        rsxAddressToOffset(fb[i], &fb_off[i]);
        gcmSetDisplayBuffer(i, fb_off[i], fb_pitch, dw, dh);
    }
    return 1;
}

/* ---------- eventos do sistema (botao PS / sair) ---------- */
static void sysutil_cb(u64 status, u64 param, void *usrdata)
{
    (void)param; (void)usrdata;
    if (status == SYSUTIL_EXIT_GAME) running = 0;
}

/* ====================================================================== */
int main(int argc, char *argv[])
{
    (void)argc; (void)argv;

    if (!init_screen()) { printf("Falha ao iniciar o video\n"); return 1; }
    sysUtilRegisterCallback(0, sysutil_cb, NULL);
    ioPadInit(7);

    FILE *logf = fopen("/dev_hdd0/tmp/asteria_log.txt", "w");

    host = (u32 *)memalign(128, (size_t)LW * LH * 4);
    bgp  = (u32 *)memalign(128, (size_t)LW * LH * 4);
    xmap = (int *)malloc(sizeof(int) * dw);
    ymap = (int *)malloc(sizeof(int) * dh);
    if (!host || !bgp || !xmap || !ymap) return 1;
    for (u32 x = 0; x < dw; x++) xmap[x] = (int)((long)x * LW / dw);
    for (u32 y = 0; y < dh; y++) ymap[y] = (int)((long)y * LH / dh);

    for (int i = 0; i < LW * LH; i++) {
        const unsigned char *p = bg_data + i * 4;
        bgp[i] = ((u32)p[0] << 16) | ((u32)p[1] << 8) | p[2];
    }
    memcpy(host, bgp, (size_t)LW * LH * 4);

    /* os dois framebuffers comecam com o fundo; mostra o 0 e desenha no 1 */
    for (int i = 0; i < 2; i++) copy_rect(fb[i], 0, 0, LW, LH);
    gcmResetFlipStatus();
    queue_flip(0);
    int b = 1;

    Button btn[NBTN];
    memset(btn, 0, sizeof(btn));
    const unsigned char *dn[NBTN] = { btn_jogar_n_data, btn_config_n_data, btn_creditos_n_data };
    const unsigned char *ds[NBTN] = { btn_jogar_s_data, btn_config_s_data, btn_creditos_s_data };
    const float ys[NBTN] = { 434.f + BTN_H / 2.f, 510.f + BTN_H / 2.f, 585.f + BTN_H / 2.f };
    const char *names[NBTN] = { "Jogar", "Configuracoes", "Creditos" };
    for (int i = 0; i < NBTN; i++) { btn[i].n = dn[i]; btn[i].s = ds[i]; btn[i].cx = LW / 2.f; btn[i].cy = ys[i]; }

    init_stars();
    Meteor meteor; memset(&meteor, 0, sizeof(meteor)); meteor.next = 2.5f;

    int sel = 0;
    float t = 0.f, intro = 0.f;
    int prev_up = 0, prev_down = 0, prev_cross = 0, axis_dir = 0;
    float hold_up = 0.f, hold_down = 0.f;
    int fps_frames = 0; float fps_acc = 0.f; int fps_show = 0;

    double last = now_sec(), log_t = last;
    unsigned frame = 0;

    while (running) {
        /* ----- sistema + controle ----- */
        stage = 1;
        sysUtilCheckCallback();

        double nowt = now_sec();
        float dt = (float)(nowt - last);
        last = nowt;
        if (dt > 0.1f) dt = 0.1f;
        if (dt < 0.f) dt = 0.f;
        t += dt; intro += dt;

        int up = 0, down = 0, cross = 0, start = 0, ay = 128;
        padInfo pinfo; padData pdata;
        ioPadGetInfo(&pinfo);
        for (int i = 0; i < MAX_PADS; i++) {
            if (pinfo.status[i]) {
                ioPadGetData(i, &pdata);
                if (pdata.BTN_UP) up = 1;
                if (pdata.BTN_DOWN) down = 1;
                if (pdata.BTN_CROSS) cross = 1;
                if (pdata.BTN_START) start = 1;
                if (pdata.len > 0) ay = pdata.ANA_L_V;
                break;
            }
        }
        if (start) running = 0;

        int dir = ay < 64 ? -1 : (ay > 192 ? 1 : 0);
        if (up && !prev_up)     { sel = (sel + NBTN - 1) % NBTN; hold_up = 0.f; }
        if (down && !prev_down) { sel = (sel + 1) % NBTN; hold_down = 0.f; }
        if (dir != axis_dir) {
            if (dir < 0) sel = (sel + NBTN - 1) % NBTN;
            if (dir > 0) sel = (sel + 1) % NBTN;
            axis_dir = dir;
        }
        if (cross && !prev_cross) { btn[sel].press = 0.001f; printf("Selecionado: %s\n", names[sel]); }
        if (up) { hold_up += dt; if (hold_up > 0.40f) { sel = (sel + NBTN - 1) % NBTN; hold_up = 0.28f; } } else hold_up = 0.f;
        if (down) { hold_down += dt; if (hold_down > 0.40f) { sel = (sel + 1) % NBTN; hold_down = 0.28f; } } else hold_down = 0.f;
        prev_up = up; prev_down = down; prev_cross = cross;

        /* ----- animacoes ----- */
        stage = 2;
        float k = clampf(dt * 14.f, 0.f, 1.f);
        for (int i = 0; i < NBTN; i++) {
            btn[i].sel = lerpf(btn[i].sel, i == sel ? 1.f : 0.f, k);
            if (btn[i].press > 0.f) { btn[i].press += dt * 3.2f; if (btn[i].press >= 1.f) btn[i].press = 0.f; }
        }
        update_meteor(&meteor, dt);

        fps_frames++; fps_acc += dt;
        if (fps_acc >= 0.5f) { fps_show = (int)(fps_frames / fps_acc + 0.5f); fps_frames = 0; fps_acc = 0.f; }
        if (fps_show > TARGET_FPS) fps_show = TARGET_FPS;

        /* ----- desenho no quadro em memoria ----- */
        stage = 3;
        RList *prev1 = &lists[(frame + 2) % 3];
        RList *prev2 = &lists[(frame + 1) % 3];
        cur = &lists[frame % 3];
        cur->n = 0; cur->full = 0;
        restore_list(prev1);

        draw_stars(t);
        draw_meteor(&meteor);
        for (int i = 0; i < NBTN; i++) draw_button(&btn[i], i, t, intro);

        char fpsbuf[32];
        snprintf(fpsbuf, sizeof(fpsbuf), "FPS: %d", fps_show);
        int px = 4, tw = text_width(fpsbuf, px), tx = (LW - tw) / 2, ty = 18;
        blend(tx - 16, ty - 10, tw + 32, 7 * px + 20, 12, 6, 34, 150);
        blend_nt(tx - 16, ty - 10 + 7 * px + 18, tw + 32, 2, 255, 160, 225, 120);
        touch(tx, ty, tw + 3, 7 * px + 3);
        draw_text_nt(fpsbuf, tx + 2, ty + 2, px, 0x280A46);
        draw_text_nt(fpsbuf, tx, ty, px, 0xFFEBFA);

        if (intro < 1.3f) {
            touch(0, 0, LW, LH);
            blend_nt(0, 0, LW, LH, 6, 3, 20, (int)((1.f - ease_out_cubic(intro / 1.3f)) * 255.f));
        }

        /* ----- envia para a tela e troca de buffer (vsync) ----- */
        stage = 4;
        wait_flip();
        stage = 5;
        copy_list(fb[b], cur);
        copy_list(fb[b], prev2);
        stage = 6;
        queue_flip(b);
        b ^= 1;
        frame++;

        if (nowt - log_t >= 1.0) {
            log_t = nowt;
            if (logf) {
                fprintf(logf, "t=%.1f frames=%u fps=%d flip_timeouts=%u stage=%d\n",
                        nowt, frame, fps_show, flip_timeouts, stage);
                fflush(logf);
            }
        }
    }

    wait_flip();
    ioPadEnd();
    if (logf) fclose(logf);
    return 0;
}
