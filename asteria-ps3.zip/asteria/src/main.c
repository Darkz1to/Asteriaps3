/*
 * Asteria - tela inicial para PS3 (SDL2 / PSL1GHT)
 * Tela cheia, background pixel art, menu navegavel (D-Pad / analogico),
 * animacoes suaves e contador de FPS no topo (limitado a 60).
 */
#include <SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>

#define SCR_W   1280
#define SCR_H   720
#define TARGET_FPS 60

/* ---------- assets embutidos no ELF (.incbin) ---------- */
#define INCBIN(sym, file)                                   \
    __asm__(".section .rodata\n"                            \
            ".balign 16\n"                                  \
            ".global " #sym "\n"                            \
            #sym ":\n"                                      \
            ".incbin \"" file "\"\n"                        \
            ".balign 16\n"                                  \
            ".previous\n");                                 \
    extern const unsigned char sym[]

INCBIN(bg_data,            "assets/bg.raw");
INCBIN(btn_jogar_n_data,   "assets/btn_jogar_n.raw");
INCBIN(btn_jogar_s_data,   "assets/btn_jogar_s.raw");
INCBIN(btn_config_n_data,  "assets/btn_config_n.raw");
INCBIN(btn_config_s_data,  "assets/btn_config_s.raw");
INCBIN(btn_creditos_n_data,"assets/btn_creditos_n.raw");
INCBIN(btn_creditos_s_data,"assets/btn_creditos_s.raw");

#define BG_W 1280
#define BG_H 720
#define BTN_W 258
#define BTN_H 55

/* ---------- utilidades ---------- */
static float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static float ease_out_cubic(float t) { t = clampf(t, 0.f, 1.f); float u = 1.f - t; return 1.f - u * u * u; }
static float lerpf(float a, float b, float t) { return a + (b - a) * t; }

static uint32_t rng_state = 0x1234ABCDu;
static uint32_t rnd(void) { rng_state ^= rng_state << 13; rng_state ^= rng_state >> 17; rng_state ^= rng_state << 5; return rng_state; }
static float rndf(void) { return (rnd() & 0xFFFFFF) / 16777216.0f; }

/* retangulo sempre recortado para dentro da tela (nada desenha fora) */
static void fill_clamped(SDL_Renderer *r, int x, int y, int w, int h)
{
    int x2 = x + w, y2 = y + h;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x2 > SCR_W) x2 = SCR_W;
    if (y2 > SCR_H) y2 = SCR_H;
    if (x2 <= x || y2 <= y) return;
    SDL_Rect q = { x, y, x2 - x, y2 - y };
    SDL_RenderFillRect(r, &q);
}

/* log de diagnostico: /dev_hdd0/tmp/asteria_log.txt
 * Escrito por uma thread separada, entao continua escrevendo mesmo que o
 * laco principal trave. "stage" diz onde o laco principal parou. */
static volatile int stage = 0;
static volatile unsigned frame_counter = 0;
static volatile int wd_run = 1;

static int watchdog_thread(void *arg)
{
    (void)arg;
    FILE *f = fopen("/dev_hdd0/tmp/asteria_log.txt", "w");
    if (!f) return 0;
    unsigned last_frames = 0xFFFFFFFFu;
    while (wd_run) {
        SDL_Delay(500);
        unsigned fr = frame_counter;
        fprintf(f, "t=%u frames=%u stage=%d%s\n", (unsigned)SDL_GetTicks(), fr, stage,
                (fr == last_frames) ? "  <-- PARADO" : "");
        fflush(f);
        last_frames = fr;
    }
    fclose(f);
    return 0;
}

/* ---------- fonte bitmap 5x7 (so o necessario para o contador) ---------- */
static const uint8_t *glyph(char c)
{
    static const uint8_t G_F[7] = {31,16,16,30,16,16,16};
    static const uint8_t G_P[7] = {30,17,17,30,16,16,16};
    static const uint8_t G_S[7] = {15,16,16,14,1,1,30};
    static const uint8_t G_C[7] = {0,4,4,0,4,4,0};
    static const uint8_t G_D[10][7] = {
        {14,17,19,21,25,17,14}, {4,12,4,4,4,4,14}, {14,17,1,2,4,8,31},
        {30,1,1,14,1,1,30},     {2,6,10,18,31,2,2}, {31,16,30,1,1,17,14},
        {6,8,16,30,17,17,14},   {31,1,2,4,8,8,8},   {14,17,17,14,17,17,14},
        {14,17,17,15,1,2,12}
    };
    if (c == 'F') return G_F;
    if (c == 'P') return G_P;
    if (c == 'S') return G_S;
    if (c == ':') return G_C;
    if (c >= '0' && c <= '9') return G_D[c - '0'];
    return NULL;
}

static void draw_text(SDL_Renderer *r, const char *s, int x, int y, int px, SDL_Color col)
{
    SDL_SetRenderDrawColor(r, col.r, col.g, col.b, col.a);
    for (; *s; s++) {
        const uint8_t *g = glyph(*s);
        if (g) {
            for (int row = 0; row < 7; row++)
                for (int c = 0; c < 5; c++)
                    if (g[row] & (1 << (4 - c))) {
                        SDL_Rect q = { x + c * px, y + row * px, px, px };
                        SDL_RenderFillRect(r, &q);
                    }
        }
        x += 6 * px;
    }
}

static int text_width(const char *s, int px) { return (int)strlen(s) * 6 * px - px; }

/* ---------- texturas ---------- */
static SDL_Texture *make_tex(SDL_Renderer *r, const unsigned char *data, int w, int h,
                             Uint32 fmt, int blend)
{
    SDL_Surface *src = SDL_CreateRGBSurfaceWithFormatFrom((void *)data, w, h, 32, w * 4,
                                                          SDL_PIXELFORMAT_RGBA32);
    if (!src) return NULL;
    SDL_Surface *conv = SDL_ConvertSurfaceFormat(src, fmt, 0);
    SDL_FreeSurface(src);
    if (!conv) return NULL;
    SDL_Texture *t = SDL_CreateTextureFromSurface(r, conv);
    SDL_FreeSurface(conv);
    if (t) SDL_SetTextureBlendMode(t, blend ? SDL_BLENDMODE_BLEND : SDL_BLENDMODE_NONE);
    return t;
}

/* ---------- estrelas cintilantes ---------- */
#define NSTARS 90
typedef struct { float x, y, ph, sp; int sz; Uint8 r, g, b; } Star;
static Star stars[NSTARS];

static void init_stars(void)
{
    for (int i = 0; i < NSTARS; i++) {
        stars[i].x  = rndf() * SCR_W;
        stars[i].y  = rndf() * (SCR_H * 0.78f);
        stars[i].ph = rndf() * 6.2831f;
        stars[i].sp = 0.8f + rndf() * 2.4f;
        stars[i].sz = (rnd() % 7 == 0) ? 3 : ((rnd() % 3 == 0) ? 2 : 1);
        int k = rnd() % 4;
        if (k == 0)      { stars[i].r = 255; stars[i].g = 200; stars[i].b = 240; }
        else if (k == 1) { stars[i].r = 190; stars[i].g = 215; stars[i].b = 255; }
        else             { stars[i].r = 255; stars[i].g = 255; stars[i].b = 255; }
    }
}

static void draw_stars(SDL_Renderer *r, float t)
{
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    for (int i = 0; i < NSTARS; i++) {
        float tw = 0.5f + 0.5f * sinf(t * stars[i].sp + stars[i].ph);
        Uint8 a = (Uint8)(tw * tw * 170.f);
        SDL_SetRenderDrawColor(r, stars[i].r, stars[i].g, stars[i].b, a);
        int s = stars[i].sz;
        int cx = (int)stars[i].x, cy = (int)stars[i].y;
        fill_clamped(r, cx, cy, s, s);
        if (s >= 3) { /* brilho em cruz nas estrelas maiores */
            SDL_SetRenderDrawColor(r, stars[i].r, stars[i].g, stars[i].b, a / 2);
            fill_clamped(r, cx - 3, cy + 1, 9, 1);
            fill_clamped(r, cx + 1, cy - 3, 1, 9);
        }
    }
}

/* ---------- estrela cadente ---------- */
typedef struct { int active; float t, dur, x0, y0, dx, dy; float next; } Meteor;

static void update_meteor(Meteor *m, float dt)
{
    if (!m->active) {
        m->next -= dt;
        if (m->next <= 0.f) {
            m->active = 1; m->t = 0.f; m->dur = 0.8f + rndf() * 0.4f;
            m->x0 = 500.f + rndf() * 700.f; m->y0 = 20.f + rndf() * 160.f;
            m->dx = -(260.f + rndf() * 140.f); m->dy = 120.f + rndf() * 70.f;
        }
    } else {
        m->t += dt;
        if (m->t >= m->dur) { m->active = 0; m->next = 3.5f + rndf() * 4.5f; }
    }
}

static void draw_meteor(SDL_Renderer *r, const Meteor *m)
{
    if (!m->active) return;
    float p = m->t / m->dur;
    float fade = sinf(p * 3.14159f);
    float hx = m->x0 + m->dx * p * 1.6f, hy = m->y0 + m->dy * p * 1.6f;
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    for (int i = 0; i < 16; i++) {
        float k = i / 16.0f;
        int x = (int)(hx - m->dx * 0.16f * k), y = (int)(hy - m->dy * 0.16f * k);
        int sz = i < 3 ? 3 : 2;
        Uint8 a = (Uint8)(fade * (1.f - k) * 230.f);
        SDL_SetRenderDrawColor(r, 255, 225, 250, a);
        fill_clamped(r, x, y, sz, sz);
    }
}

/* ---------- botoes ---------- */
#define NBTN 3
typedef struct {
    SDL_Texture *n, *s;
    float cx, cy;      /* centro base */
    float sel;         /* 0..1 transicao normal -> selecionado */
    float scale;       /* escala suave */
    float press;       /* animacao de clique 0..1 */
} Button;

static void draw_diamond(SDL_Renderer *r, int cx, int cy, int px, Uint8 a)
{
    static const int w[5] = {1, 3, 5, 3, 1};
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(r, 255, 170, 230, a);
    for (int row = 0; row < 5; row++) {
        fill_clamped(r, cx - (w[row] * px) / 2, cy + (row - 2) * px, w[row] * px, px);
    }
}

static void draw_button(SDL_Renderer *r, Button *b, int index, float t, float intro)
{
    float e = ease_out_cubic((intro - 0.35f - index * 0.14f) / 0.55f);
    if (e <= 0.f) return;

    /* sem escalonamento de imagem: so deslocamento (blit 1:1, sem alocacoes) */
    float slide = (1.f - e) * 30.f;
    float lift  = -4.f * b->sel + 4.f * sinf(b->press * 3.14159f);
    SDL_Rect d = { (int)(b->cx - BTN_W / 2), (int)(b->cy - BTN_H / 2 + slide + lift), BTN_W, BTN_H };
    Uint8 alpha = (Uint8)(e * 255.f);

    if (b->sel > 0.02f) {
        float pulse = 0.65f + 0.35f * sinf(t * 4.2f);
        SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
        for (int i = 3; i >= 1; i--) {
            int g = i * 4;
            Uint8 ga = (Uint8)(b->sel * pulse * e * (28.f - i * 6.f));
            SDL_SetRenderDrawColor(r, 255, 140, 220, ga);
            fill_clamped(r, d.x - g, d.y - g, d.w + g * 2, d.h + g * 2);
        }
        float bob = sinf(t * 5.f) * 4.f;
        Uint8 da = (Uint8)(b->sel * e * 235.f);
        draw_diamond(r, d.x - 26 - (int)bob, d.y + d.h / 2, 3, da);
        draw_diamond(r, d.x + d.w + 26 + (int)bob, d.y + d.h / 2, 3, da);
    }

    SDL_SetTextureAlphaMod(b->n, alpha);
    SDL_RenderCopy(r, b->n, NULL, &d);
    if (b->sel > 0.01f) {
        SDL_SetTextureAlphaMod(b->s, (Uint8)(b->sel * alpha));
        SDL_RenderCopy(r, b->s, NULL, &d);
    }
    if (b->press > 0.01f && b->press < 0.6f) { /* flash ao confirmar */
        SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(r, 255, 210, 245, (Uint8)((0.6f - b->press) * 150.f));
        SDL_RenderFillRect(r, &d);
    }
}

/* ---------- controles ---------- */
static SDL_GameController *pad = NULL;

static void open_first_pad(void)
{
    if (pad) return;
    for (int i = 0; i < SDL_NumJoysticks(); i++)
        if (SDL_IsGameController(i)) { pad = SDL_GameControllerOpen(i); if (pad) break; }
}

/* ---------- main ---------- */
int main(int argc, char *argv[])
{
    (void)argc; (void)argv;

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_GAMECONTROLLER) != 0) {
        printf("SDL_Init falhou: %s\n", SDL_GetError());
        return 1;
    }

    SDL_Window *win = SDL_CreateWindow("Asteria", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
                                       SCR_W, SCR_H, SDL_WINDOW_FULLSCREEN);
    if (!win) { printf("Janela falhou: %s\n", SDL_GetError()); SDL_Quit(); return 1; }

    SDL_Renderer *ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_SOFTWARE);
    if (!ren) { printf("Renderer falhou: %s\n", SDL_GetError()); SDL_DestroyWindow(win); SDL_Quit(); return 1; }
    {
        int ww = SCR_W, wh = SCR_H;
        SDL_GetWindowSize(win, &ww, &wh);
        if (ww != SCR_W || wh != SCR_H) { /* centraliza sem escalar */
            SDL_Rect vp = { (ww - SCR_W) / 2, (wh - SCR_H) / 2, SCR_W, SCR_H };
            SDL_RenderSetViewport(ren, &vp);
        }
    }
    SDL_Thread *wd = SDL_CreateThread(watchdog_thread, "watchdog", NULL);
    SDL_ShowCursor(SDL_DISABLE);

    /* o fundo usa o mesmo formato de pixel da janela (blit sem conversao = mais rapido) */
    Uint32 wf = SDL_GetWindowPixelFormat(win);
    if (wf == SDL_PIXELFORMAT_UNKNOWN) wf = SDL_PIXELFORMAT_ARGB8888;
    SDL_Texture *bg = make_tex(ren, bg_data, BG_W, BG_H, wf, 0);
    if (!bg) bg = make_tex(ren, bg_data, BG_W, BG_H, SDL_PIXELFORMAT_ARGB8888, 0);

    Button btn[NBTN];
    memset(btn, 0, sizeof(btn));
    const unsigned char *dn[NBTN] = { btn_jogar_n_data, btn_config_n_data, btn_creditos_n_data };
    const unsigned char *ds[NBTN] = { btn_jogar_s_data, btn_config_s_data, btn_creditos_s_data };
    const float ys[NBTN] = { 434.f + BTN_H / 2.f, 510.f + BTN_H / 2.f, 585.f + BTN_H / 2.f };
    const char *names[NBTN] = { "Jogar", "Configuracoes", "Creditos" };
    for (int i = 0; i < NBTN; i++) {
        btn[i].n = make_tex(ren, dn[i], BTN_W, BTN_H, SDL_PIXELFORMAT_ARGB8888, 1);
        btn[i].s = make_tex(ren, ds[i], BTN_W, BTN_H, SDL_PIXELFORMAT_ARGB8888, 1);
        btn[i].cx = SCR_W / 2.f;
        btn[i].cy = ys[i];
        btn[i].scale = 1.f;
    }
    if (!bg || !btn[0].n || !btn[0].s) { printf("Falha ao criar texturas: %s\n", SDL_GetError()); return 1; }

    init_stars();
    Meteor meteor; memset(&meteor, 0, sizeof(meteor)); meteor.next = 2.5f;

    open_first_pad();

    int sel = 0, running = 1;
    float t = 0.f, intro = 0.f;
    int axis_dir = 0;                 /* estado do analogico */
    float hold_up = 0.f, hold_down = 0.f;

    int fps_frames = 0; float fps_acc = 0.f; int fps_show = 0;

    Uint32 last = SDL_GetTicks();

    while (running) {
        /* ----- eventos ----- */
        stage = 1;
        SDL_Event ev;
        while (SDL_PollEvent(&ev)) {
            switch (ev.type) {
            case SDL_QUIT: running = 0; break;
            case SDL_CONTROLLERDEVICEADDED:
                if (!pad) pad = SDL_GameControllerOpen(ev.cdevice.which);
                break;
            case SDL_CONTROLLERDEVICEREMOVED:
                if (pad) { SDL_GameControllerClose(pad); pad = NULL; open_first_pad(); }
                break;
            case SDL_CONTROLLERBUTTONDOWN:
                switch (ev.cbutton.button) {
                case SDL_CONTROLLER_BUTTON_DPAD_UP:   sel = (sel + NBTN - 1) % NBTN; hold_up = 0.f; break;
                case SDL_CONTROLLER_BUTTON_DPAD_DOWN: sel = (sel + 1) % NBTN; hold_down = 0.f; break;
                case SDL_CONTROLLER_BUTTON_A:
                    btn[sel].press = 0.001f; printf("Selecionado: %s\n", names[sel]); break;
                case SDL_CONTROLLER_BUTTON_START: running = 0; break;
                }
                break;
            case SDL_CONTROLLERAXISMOTION:
                if (ev.caxis.axis == SDL_CONTROLLER_AXIS_LEFTY) {
                    int dir = ev.caxis.value < -16000 ? -1 : (ev.caxis.value > 16000 ? 1 : 0);
                    if (dir != axis_dir) {
                        if (dir < 0) sel = (sel + NBTN - 1) % NBTN;
                        if (dir > 0) sel = (sel + 1) % NBTN;
                        axis_dir = dir;
                    }
                }
                break;
            case SDL_KEYDOWN: /* para testar no PC / RPCS3 com teclado */
                if (ev.key.keysym.sym == SDLK_UP)     sel = (sel + NBTN - 1) % NBTN;
                if (ev.key.keysym.sym == SDLK_DOWN)   sel = (sel + 1) % NBTN;
                if (ev.key.keysym.sym == SDLK_RETURN) { btn[sel].press = 0.001f; printf("Selecionado: %s\n", names[sel]); }
                if (ev.key.keysym.sym == SDLK_ESCAPE) running = 0;
                break;
            }
        }

        /* ----- tempo ----- */
        stage = 2;
        Uint32 now = SDL_GetTicks();
        float dt = (float)(now - last) / 1000.0f;
        last = now;
        if (dt > 0.1f) dt = 0.1f;
        t += dt;
        intro += dt;

        stage = 20;
        /* repeticao ao segurar o D-Pad */
        if (pad) {
            if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_DPAD_UP)) {
                hold_up += dt;
                if (hold_up > 0.40f) { sel = (sel + NBTN - 1) % NBTN; hold_up = 0.28f; }
            } else hold_up = 0.f;
            if (SDL_GameControllerGetButton(pad, SDL_CONTROLLER_BUTTON_DPAD_DOWN)) {
                hold_down += dt;
                if (hold_down > 0.40f) { sel = (sel + 1) % NBTN; hold_down = 0.28f; }
            } else hold_down = 0.f;
        }

        stage = 30;
        /* ----- animacoes ----- */
        float k = clampf(dt * 14.f, 0.f, 1.f);
        for (int i = 0; i < NBTN; i++) {
            btn[i].sel   = lerpf(btn[i].sel,   i == sel ? 1.f : 0.f, k);
            btn[i].scale = lerpf(btn[i].scale, i == sel ? 1.07f : 1.f, k);
            if (btn[i].press > 0.f) { btn[i].press += dt * 3.2f; if (btn[i].press >= 1.f) btn[i].press = 0.f; }
        }
        update_meteor(&meteor, dt);

        fps_frames++; fps_acc += dt;
        if (fps_acc >= 0.5f) { fps_show = (int)(fps_frames / fps_acc + 0.5f); fps_frames = 0; fps_acc = 0.f; }
        if (fps_show > TARGET_FPS) fps_show = TARGET_FPS;

        /* ----- desenho ----- */
        stage = 3;
        SDL_RenderCopy(ren, bg, NULL, NULL);
        stage = 4; draw_stars(ren, t);
        stage = 5; draw_meteor(ren, &meteor);
        stage = 6;
        for (int i = 0; i < NBTN; i++) { stage = 60 + i; draw_button(ren, &btn[i], i, t, intro); }
        stage = 70;

        /* contador de FPS (topo, centralizado) */
        char fpsbuf[32];
        snprintf(fpsbuf, sizeof(fpsbuf), "FPS: %d", fps_show);
        int px = 4, tw = text_width(fpsbuf, px), tx = (SCR_W - tw) / 2, ty = 18;
        SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(ren, 12, 6, 34, 150);
        SDL_Rect pill = { tx - 16, ty - 10, tw + 32, 7 * px + 20 };
        SDL_RenderFillRect(ren, &pill);
        SDL_SetRenderDrawColor(ren, 255, 160, 225, 120);
        SDL_Rect line = { pill.x, pill.y + pill.h - 2, pill.w, 2 };
        SDL_RenderFillRect(ren, &line);
        SDL_Color sh = { 40, 10, 70, 255 }, fg = { 255, 235, 250, 255 };
        stage = 71;
        draw_text(ren, fpsbuf, tx + 2, ty + 2, px, sh);
        draw_text(ren, fpsbuf, tx, ty, px, fg);

        stage = 72;
        /* fade-in inicial */
        if (intro < 1.3f) {
            SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
            SDL_SetRenderDrawColor(ren, 6, 3, 20, (Uint8)((1.f - ease_out_cubic(intro / 1.3f)) * 255.f));
            SDL_RenderFillRect(ren, NULL);
        }

        stage = 80;
        SDL_RenderPresent(ren);

        /* ----- limitador de 60 FPS (uma unica espera, sem laco) ----- */
        stage = 90;
        Uint32 el = SDL_GetTicks() - now;
        if (el < 16) SDL_Delay(16 - el);
        frame_counter++;
    }

    wd_run = 0;
    if (wd) SDL_WaitThread(wd, NULL);
    if (pad) SDL_GameControllerClose(pad);
    for (int i = 0; i < NBTN; i++) { SDL_DestroyTexture(btn[i].n); SDL_DestroyTexture(btn[i].s); }
    SDL_DestroyTexture(bg);
    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    SDL_Quit();
    return 0;
}
