# Asteria (PS3)

Tela inicial: tela cheia, background pixel art, menu Jogar / Configuracoes / Creditos,
contador de FPS no topo (limitado a 60).

## Controles
- D-Pad cima/baixo (ou analogico esquerdo): navegar entre os botoes
- X: confirmar (animacao de clique)
- START: sair

## Compilar pelo GitHub
1. Crie um repositorio e suba **todo** o conteudo desta pasta (inclui `.github/`).
2. Aba **Actions** > "Build Asteria PS3" (roda sozinho a cada push, ou clique em *Run workflow*).
3. Baixe o artefato **Asteria-PS3** (`asteria.pkg`) e instale no PS3.

## Estrutura
- `src/main.c` - jogo (PSL1GHT nativo: RSX + libio, sem SDL)
- `assets/*.raw` - background e botoes embutidos no executavel
- `assets/sprites/` - sprites extraidos (moldura normal/selecionada, texto, botoes completos)
- `Makefile` / `.github/workflows/build.yml` - build com a imagem Docker `hldtux/ps3dev-sdl2`

## Diagnostico
O jogo grava `/dev_hdd0/tmp/asteria_log.txt` (1 linha/segundo: frames, fps, flip_timeouts).
Para melhor nitidez, deixe o PS3 em 720p (outras resolucoes sao escaladas).
